from datetime import datetime
from re import sub
from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from .models import DailyDrop, DailyDropItem, Product, Purchase, User, db
from .workers import ensure_drop_now, reset_today_drop, save_picture


main = Blueprint("main", __name__)


# Эта функция считает секунды до обновления
def left_seconds(refresh_at):
    left = int((refresh_at - datetime.now()).total_seconds())
    return max(left, 0)


# Эта функция получает текущий дроп и товары
def get_drop_items():
    drop = ensure_drop_now()
    return drop, [row.product for row in drop.items]


# Эта функция делает простой slug
def make_slug(text):
    raw = sub(r"[^a-zA-Z0-9а-яА-Я]+", "-", text.lower()).strip("-")
    return raw or f"item-{int(datetime.now().timestamp())}"


# Эта функция проверяет администратора
def admin_only():
    if not current_user.is_authenticated or not current_user.is_admin:
        abort(403)


# Эта функция проверяет дроп перед запросом
@main.before_app_request
def check_drop():
    ensure_drop_now()


# Это главная страница
@main.route("/")
def index():
    drop, items = get_drop_items()
    return render_template("index.html", items=items, drop=drop, seconds_left=left_seconds(drop.refresh_at))


# Это страница регистрации
@main.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not username or not email or not password:
            flash("Заполните все поля")
        elif User.query.filter_by(username=username).first():
            flash("Такой логин уже занят")
        elif User.query.filter_by(email=email).first():
            flash("Такая почта уже занята")
        else:
            user = User(username=username, email=email)
            if User.query.count() == 0:
                user.is_admin = True
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Аккаунт создан")
            return redirect(url_for("main.index"))
    return render_template("register.html")


# Это страница входа
@main.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            flash("Неверная почта или пароль")
        else:
            login_user(user)
            flash("Вы вошли")
            return redirect(url_for("main.index"))
    return render_template("login.html")


# Эта функция делает выход из аккаунта
@main.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из аккаунта")
    return redirect(url_for("main.index"))


# Это страница товара
@main.route("/product/<int:product_id>")
def product_page(product_id):
    drop, items = get_drop_items()
    product = Product.query.get_or_404(product_id)
    day_ids = [item.id for item in items]
    in_drop = product.id in day_ids
    return render_template("product.html", product=product, in_drop=in_drop, drop=drop, seconds_left=left_seconds(drop.refresh_at))


# Эта функция сохраняет покупку
@main.route("/buy/<int:product_id>", methods=["POST"])
@login_required
def buy(product_id):
    drop, items = get_drop_items()
    day_ids = [item.id for item in items]
    if product_id not in day_ids:
        abort(404)
    product = Product.query.get_or_404(product_id)
    row = Purchase(user_id=current_user.id, product_id=product.id, price_now=product.price)
    db.session.add(row)
    db.session.commit()
    flash("Покупка записана в историю")
    return redirect(url_for("main.history"))


# Это история покупок
@main.route("/history")
@login_required
def history():
    buys = Purchase.query.filter_by(user_id=current_user.id).order_by(Purchase.made_at.desc()).all()
    return render_template("history.html", buys=buys)


# Это профиль пользователя
@main.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        file = request.files.get("avatar")
        if not file or not file.filename:
            flash("Выберите файл")
        else:
            try:
                image_name = save_picture(file, current_app.config["UPLOAD_FOLDER"])
                current_user.avatar = image_name
                db.session.commit()
                flash("Аватар обновлен")
                return redirect(url_for("main.profile"))
            except ValueError:
                flash("Нужна картинка в формате png, jpg, jpeg, gif или webp")
    my_buys = Purchase.query.filter_by(user_id=current_user.id).order_by(Purchase.made_at.desc()).limit(5).all()
    return render_template("profile.html", my_buys=my_buys)


# Это api с товарами на сегодня
@main.route("/api/products/today")
def api_today():
    drop, items = get_drop_items()
    return jsonify({
        "day": drop.day.isoformat(),
        "refresh_at": drop.refresh_at.isoformat(),
        "seconds_left": left_seconds(drop.refresh_at),
        "count": len(items),
        "products": [{"id": item.id, "title": item.title, "category": item.category, "price": item.price, "info": item.info, "image": item.image} for item in items],
    })


# Это api одного товара
@main.route("/api/products/<int:product_id>")
def api_product(product_id):
    item = Product.query.get_or_404(product_id)
    return jsonify({
        "id": item.id,
        "title": item.title,
        "slug": item.slug,
        "category": item.category,
        "price": item.price,
        "info": item.info,
        "image": item.image,
    })


# Это страница прошлых дропов
@main.route("/drops")
def drops():
    rows = DailyDrop.query.order_by(DailyDrop.day.desc()).limit(7).all()
    return render_template("drops.html", rows=rows)


# Это страница управления товарами
@main.route("/admin/products", methods=["GET", "POST"])
@login_required
def admin_products():
    admin_only()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "").strip()
        info = request.form.get("info", "").strip()
        price_text = request.form.get("price", "").strip()
        image = request.files.get("image")
        image_link = request.form.get("image_link", "").strip()
        if not title or not category or not info or not price_text:
            flash("Заполните обязательные поля")
        else:
            try:
                price = int(price_text)
                if price <= 0:
                    raise ValueError
            except ValueError:
                flash("Цена должна быть положительным числом")
                products = Product.query.order_by(Product.made_at.desc()).all()
                return render_template("admin_products.html", products=products)
            slug = make_slug(title)
            if Product.query.filter_by(slug=slug).first():
                slug = f"{slug}-{int(datetime.now().timestamp())}"
            image_value = image_link or "https://placehold.co/600x400?text=No+Image"
            if image and image.filename:
                try:
                    image_name = save_picture(image, current_app.config["UPLOAD_FOLDER"])
                    image_value = url_for("static", filename=f"uploads/{image_name}")
                except ValueError:
                    flash("Картинка должна быть png, jpg, jpeg, gif или webp")
                    products = Product.query.order_by(Product.made_at.desc()).all()
                    return render_template("admin_products.html", products=products)
            row = Product(title=title, slug=slug, category=category, price=price, info=info, image=image_value)
            db.session.add(row)
            db.session.commit()
            flash("Товар добавлен")
            return redirect(url_for("main.admin_products"))
    products = Product.query.order_by(Product.made_at.desc()).all()
    return render_template("admin_products.html", products=products)


# Эта функция удаляет товар
@main.route("/admin/products/<int:product_id>/delete", methods=["POST"])
@login_required
def delete_product(product_id):
    admin_only()
    product = Product.query.get_or_404(product_id)
    DailyDropItem.query.filter_by(product_id=product.id).delete()
    Purchase.query.filter_by(product_id=product.id).delete()
    db.session.delete(product)
    db.session.commit()
    flash("Товар удален")
    return redirect(url_for("main.admin_products"))


# Эта функция обновляет дроп вручную
@main.route("/admin/drop/reset", methods=["POST"])
@login_required
def reset_drop():
    admin_only()
    reset_today_drop()
    flash("Сегодняшний дроп обновлен")
    return redirect(url_for("main.index"))
