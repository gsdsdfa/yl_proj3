import os

from flask import Flask
from flask_login import LoginManager

from .models import User, db
from .views import main
from .workers import ensure_drop_now, fill_products, start_drop_worker


login_manager = LoginManager()
login_manager.login_view = "main.login"
login_manager.login_message = "Сначала войдите в аккаунт"


# Эта функция загружает пользователя по id
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# Эта функция создает приложение
def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "daily-shop-secret")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///daily_shop.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["UPLOAD_FOLDER"] = os.path.join(app.static_folder, "uploads")
    app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

    db.init_app(app)
    login_manager.init_app(app)
    app.register_blueprint(main)

    with app.app_context():
        db.create_all()
        fill_products()
        ensure_drop_now()

    start_drop_worker(app)
    return app
