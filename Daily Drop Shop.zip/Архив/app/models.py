from datetime import datetime
from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


# Это таблица пользователей
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    avatar = db.Column(db.String(255), nullable=False, default="default_avatar.png")
    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    buys = db.relationship("Purchase", back_populates="user", lazy=True)

    # Эта функция сохраняет пароль
    def set_password(self, raw_password):
        self.password_hash = raw_password

    # Эта функция проверяет пароль
    def check_password(self, raw_password):
        return self.password_hash == raw_password


# Это таблица товаров
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    category = db.Column(db.String(60), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    info = db.Column(db.Text, nullable=False)
    image = db.Column(db.String(255), nullable=False)
    made_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    drop_items = db.relationship("DailyDropItem", back_populates="product", lazy=True)
    buys = db.relationship("Purchase", back_populates="product", lazy=True)


# Это таблица дропа на день
class DailyDrop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    day = db.Column(db.Date, unique=True, nullable=False)
    refresh_at = db.Column(db.DateTime, nullable=False)
    made_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    items = db.relationship(
        "DailyDropItem",
        back_populates="drop",
        cascade="all, delete-orphan",
        lazy=True,
        order_by="DailyDropItem.row_num",
    )


# Это таблица товаров внутри дропа
class DailyDropItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    drop_id = db.Column(db.Integer, db.ForeignKey("daily_drop.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    row_num = db.Column(db.Integer, nullable=False, default=0)

    drop = db.relationship("DailyDrop", back_populates="items")
    product = db.relationship("Product", back_populates="drop_items")


# Это таблица покупок
class Purchase(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    price_now = db.Column(db.Integer, nullable=False)
    made_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="buys")
    product = db.relationship("Product", back_populates="buys")
