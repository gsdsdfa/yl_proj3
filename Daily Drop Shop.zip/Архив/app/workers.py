import os
import random
import threading
import time
from datetime import date, datetime, time as dt_time, timedelta
from uuid import uuid4
import schedule
from .models import DailyDrop, DailyDropItem, Product, db


stuff = [
    {"title": "Неоновая кружка", "slug": "neon-mug", "category": "Дом", "price": 890, "info": "Кружка, которая выглядит так, будто приехала из аркадного автомата.", "image": "https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?auto=format&fit=crop&w=900&q=80"},
    {"title": "Клавиатура без причины", "slug": "odd-keyboard", "category": "Техника", "price": 4590, "info": "Механическая клавиатура для тех, кто любит щелкать громче, чем думать.", "image": "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&w=900&q=80"},
    {"title": "Плед с кактусами", "slug": "cactus-blanket", "category": "Дом", "price": 2390, "info": "Мягкий плед, который выглядит опаснее, чем есть на самом деле.", "image": "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80"},
    {"title": "Лампа для ночных идей", "slug": "night-lamp", "category": "Свет", "price": 3190, "info": "Небольшая лампа для тех моментов, когда идея пришла слишком поздно.", "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80"},
    {"title": "Плюшевый осьминог", "slug": "soft-octopus", "category": "Игрушки", "price": 1290, "info": "Игрушка для поднятия настроения и странных подарков.", "image": "https://images.unsplash.com/photo-1545558014-8692077e9b5c?auto=format&fit=crop&w=900&q=80"},
    {"title": "Карманный проектор", "slug": "pocket-projector", "category": "Техника", "price": 6990, "info": "Показывает кино на стене, потолке и иногда на холодильнике.", "image": "https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?auto=format&fit=crop&w=900&q=80"},
    {"title": "Сухой букет", "slug": "dry-bouquet", "category": "Декор", "price": 990, "info": "Декор для тех, кто не дружит с поливом, но любит уют.", "image": "https://images.unsplash.com/photo-1477414348463-c0eb7f1359b6?auto=format&fit=crop&w=900&q=80"},
    {"title": "Рюкзак-пингвин", "slug": "penguin-bag", "category": "Одежда", "price": 2890, "info": "Смешной рюкзак, в который внезапно помещается слишком много вещей.", "image": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80"},
    {"title": "Настольный вентилятор", "slug": "tiny-fan", "category": "Техника", "price": 1490, "info": "Мини-вентилятор для тех, кто спорит с летом каждый год.", "image": "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80"},
    {"title": "Постер с луной", "slug": "moon-poster", "category": "Декор", "price": 790, "info": "Постер для стены, которая выглядит слишком пустой.", "image": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80"},
    {"title": "Коробка тайных сладостей", "slug": "mystery-sweets", "category": "Еда", "price": 1690, "info": "Набор конфет без подсказок. В этом и весь смысл.", "image": "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=900&q=80"},
    {"title": "Мини-камера на клипсе", "slug": "clip-camera", "category": "Техника", "price": 5290, "info": "Камера для быстрых кадров, неловких ракурсов и хороших историй.", "image": "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=80"},
]


# Эта функция считает время следующей смены
def next_swap_time():
    tomorrow = date.today() + timedelta(days=1)
    return datetime.combine(tomorrow, dt_time.min)


# Эта функция добавляет стартовые товары
def fill_products():
    if Product.query.count():
        return
    for box in stuff:
        db.session.add(Product(**box))
    db.session.commit()


# Эта функция ищет дроп на сегодня
def get_today_drop():
    return DailyDrop.query.filter_by(day=date.today()).first()


# Эта функция создает новый дроп
def make_drop():
    old = get_today_drop()
    if old:
        return old
    all_items = Product.query.all()
    how_many = random.randint(3, 5)
    picked = random.sample(all_items, min(how_many, len(all_items)))
    fresh = DailyDrop(day=date.today(), refresh_at=next_swap_time())
    db.session.add(fresh)
    db.session.flush()
    for num, item in enumerate(picked, start=1):
        db.session.add(DailyDropItem(drop_id=fresh.id, product_id=item.id, row_num=num))
    db.session.commit()
    return fresh


# Эта функция возвращает дроп на сегодня
def ensure_drop_now():
    return get_today_drop() or make_drop()


# Эта функция пересоздает дроп на сегодня
def reset_today_drop():
    old = get_today_drop()
    if old:
        db.session.delete(old)
        db.session.commit()
    return make_drop()


# Эта функция сохраняет картинку
def save_picture(file_storage, upload_folder):
    os.makedirs(upload_folder, exist_ok=True)
    if "." not in file_storage.filename:
        raise ValueError("bad file")
    ext = file_storage.filename.rsplit(".", 1)[-1].lower()
    if ext not in {"png", "jpg", "jpeg", "gif", "webp"}:
        raise ValueError("bad file")
    fresh_name = f"{uuid4().hex}.{ext}"
    file_storage.save(os.path.join(upload_folder, fresh_name))
    return fresh_name


# Эта функция запускает ежедневную задачу
def run_daily_job(app):
    with app.app_context():
        ensure_drop_now()
        border = date.today() - timedelta(days=6)
        old = DailyDrop.query.filter(DailyDrop.day < border).all()
        for row in old:
            db.session.delete(row)
        db.session.commit()


# Эта функция крутит schedule в цикле
def job_loop():
    while True:
        schedule.run_pending()
        time.sleep(1)


# Эта функция запускает фоновый поток
def start_drop_worker(app):
    if getattr(app, "_worker_started", False):
        return
    with app.app_context():
        ensure_drop_now()
    schedule.every().day.at("00:00").do(run_daily_job, app)
    thread = threading.Thread(target=job_loop, daemon=True)
    thread.start()
    app._worker_started = True
